import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;
import java.io.*;
import java.net.*;
import java.util.*;
import javax.imageio.ImageIO;
import javax.sound.sampled.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Desktop;

public class ChatClient extends JFrame {
    private JTextPane chatPane;
    private JTextField inputField;
    private JButton sendButton, imageButton, voiceButton, fileButton;
    private JComboBox<String> destSelector;
    private DefaultListModel<String> listModel;
    private JList<String> userList;
    private JLabel userLabel;

    private Socket socket;
    private DataInputStream in;
    private DataOutputStream out;
    private String name;

    private boolean recording = false;
    private TargetDataLine microphone;
    private File currentAudioFile;

    public ChatClient(String serverAddress, int port) {
        name = JOptionPane.showInputDialog(this, "Entrez votre pseudo :");
        if (name == null || name.trim().isEmpty()) name = "Client" + new Random().nextInt(1000);

        setTitle(name + " - Chat (Texte + Image + Vocal + Fichier)");
        setSize(700, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        userLabel = new JLabel("Connecté en tant que : " + name);
        add(userLabel, BorderLayout.NORTH);

        chatPane = new JTextPane();
        chatPane.setEditable(false);
        add(new JScrollPane(chatPane), BorderLayout.CENTER);

        JPanel bottom = new JPanel(new BorderLayout());
        inputField = new JTextField();
        sendButton = new JButton("Envoyer");
        imageButton = new JButton("📸 Image");
        voiceButton = new JButton("🎙️ Vocal");
        fileButton = new JButton("📁 Fichier");

        JPanel topBottom = new JPanel(new FlowLayout(FlowLayout.LEFT));
        destSelector = new JComboBox<>();
        destSelector.addItem("TOUS");
        topBottom.add(new JLabel("À :"));
        topBottom.add(destSelector);
        topBottom.add(imageButton);
        topBottom.add(voiceButton);
        topBottom.add(fileButton);
        bottom.add(topBottom, BorderLayout.NORTH);

        JPanel msgPanel = new JPanel(new BorderLayout());
        msgPanel.add(inputField, BorderLayout.CENTER);
        msgPanel.add(sendButton, BorderLayout.EAST);
        bottom.add(msgPanel, BorderLayout.SOUTH);

        add(bottom, BorderLayout.SOUTH);

        listModel = new DefaultListModel<>();
        userList = new JList<>(listModel);
        userList.setBorder(BorderFactory.createTitledBorder("Connectés"));
        add(new JScrollPane(userList), BorderLayout.EAST);

        try {
            socket = new Socket(serverAddress, port);
            in = new DataInputStream(socket.getInputStream());
            out = new DataOutputStream(socket.getOutputStream());
            out.writeUTF(name);
            out.flush();
            new Thread(this::listenServer).start();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Connexion impossible au serveur.", "Erreur", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }

        sendButton.addActionListener(e -> sendMessage());
        inputField.addActionListener(e -> sendMessage());
        imageButton.addActionListener(e -> sendImage());
        voiceButton.addActionListener(e -> toggleVoiceRecording());
        fileButton.addActionListener(e -> sendFile());

        setVisible(true);
    }

    private String getTimestamp() {
        return new java.text.SimpleDateFormat("HH:mm:ss").format(new Date());
    }

    private void sendMessage() {
        String msg = inputField.getText().trim();
        if (msg.isEmpty()) return;
        String dest = (String) destSelector.getSelectedItem();
        if (dest == null) dest = "TOUS";
        try {
            out.writeUTF("TEXT");
            out.writeUTF(dest);
            out.writeUTF(getTimestamp());
            out.writeUTF(msg);
            out.flush();
            appendText("[" + getTimestamp() + "] Moi -> " + (dest.equals("TOUS") ? "Tous" : dest) + " : " + msg + "\n", Color.BLUE);
            inputField.setText("");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void sendImage() {
        JFileChooser chooser = new JFileChooser();
        if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            File file = chooser.getSelectedFile();
            sendBinaryFile("IMG", file);
        }
    }

    private void sendFile() {
        JFileChooser chooser = new JFileChooser();
        if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            File file = chooser.getSelectedFile();
            sendBinaryFile("FILE", file);
        }
    }

    private void sendBinaryFile(String type, File file) {
        String dest = (String) destSelector.getSelectedItem();
        if (dest == null) dest = "TOUS";
        try {
            byte[] data = java.nio.file.Files.readAllBytes(file.toPath());
            out.writeUTF(type);
            out.writeUTF(dest);
            out.writeUTF(file.getName());
            out.writeInt(data.length);
            out.write(data);
            out.flush();
            appendText("[" + getTimestamp() + "] Moi -> " + dest + " : " + file.getName() + "\n", Color.BLUE);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void toggleVoiceRecording() {
        if (!recording) startRecording();
        else stopRecordingAndSend();
    }

    private void startRecording() {
        try {
            AudioFormat format = new AudioFormat(16000, 16, 2, true, true);
            DataLine.Info info = new DataLine.Info(TargetDataLine.class, format);
            microphone = (TargetDataLine) AudioSystem.getLine(info);
            microphone.open(format);
            microphone.start();

            currentAudioFile = new File("voice_" + System.currentTimeMillis() + ".wav");
            new Thread(() -> {
                try (AudioInputStream ais = new AudioInputStream(microphone)) {
                    AudioSystem.write(ais, AudioFileFormat.Type.WAVE, currentAudioFile);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }).start();

            recording = true;
            voiceButton.setText("⏹️ Stop");
            appendText("🎙️ Enregistrement...\n", Color.GRAY);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void stopRecordingAndSend() {
        try {
            microphone.stop();
            microphone.close();
            recording = false;
            voiceButton.setText("🎙️ Vocal");
            appendText("🎤 Envoi du vocal...\n", Color.GRAY);

            String dest = (String) destSelector.getSelectedItem();
            if (dest == null) dest = "TOUS";
            byte[] data = java.nio.file.Files.readAllBytes(currentAudioFile.toPath());
            out.writeUTF("AUDIO");
            out.writeUTF(dest);
            out.writeUTF(currentAudioFile.getName());
            out.writeInt(data.length);
            out.write(data);
            out.flush();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void listenServer() {
        try {
            while (true) {
                String type = in.readUTF();
                if (type.equals("TEXT")) {
                    String target = in.readUTF();
                    String msg = in.readUTF();
                    appendText(msg + "\n", target.equals("ALL") ? Color.BLACK : Color.MAGENTA);
                } else if (type.equals("IMG")) {
                    receiveFile("IMG");
                } else if (type.equals("AUDIO")) {
                    receiveFile("AUDIO");
                } else if (type.equals("FILE")) {
                    receiveFile("FILE");
                } else if (type.equals("LISTE")) {
                    String listStr = in.readUTF();
                    updateUserList(listStr);
                }
            }
        } catch (IOException e) {
            appendText("⚠️ Déconnecté.\n", Color.RED);
        }
    }

    private void receiveFile(String type) throws IOException {
        String sender = in.readUTF();
        String filename = in.readUTF();
        int size = in.readInt();
        byte[] data = new byte[size];
        in.readFully(data);

        File file = new File("received_" + filename);
        try (FileOutputStream fos = new FileOutputStream(file)) {
            fos.write(data);
        }

        if (type.equals("IMG")) appendImage(file);
        else if (type.equals("AUDIO")) appendAudioMessage(sender, file);
        else if (type.equals("FILE")) appendFileMessage(sender, file);
    }

    private void appendText(String msg, Color color) {
        StyledDocument doc = chatPane.getStyledDocument();
        Style style = chatPane.addStyle("Style", null);
        StyleConstants.setForeground(style, color);
        try {
            doc.insertString(doc.getLength(), msg, style);
            chatPane.setCaretPosition(doc.getLength());
        } catch (BadLocationException e) {
            e.printStackTrace();
        }
    }

    private void appendImage(File file) {
        try {
            ImageIcon icon = new ImageIcon(ImageIO.read(file));
            chatPane.setCaretPosition(chatPane.getDocument().getLength());
            chatPane.insertIcon(icon);
            appendText("\n", Color.BLACK);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void appendAudioMessage(String sender, File audioFile) {
        JButton playBtn = new JButton("▶️ Écouter " + sender);
        playBtn.addActionListener(e -> playAudio(audioFile));
        chatPane.insertComponent(playBtn);
        appendText("\n", Color.BLACK);
    }

    private void appendFileMessage(String sender, File file) {
        JButton openBtn = new JButton("📂 Ouvrir " + file.getName() + " (" + sender + ")");
        openBtn.addActionListener(e -> openFile(file));
        chatPane.insertComponent(openBtn);
        appendText("\n", Color.BLACK);
    }

    private void playAudio(File file) {
        try {
            AudioInputStream ais = AudioSystem.getAudioInputStream(file);
            Clip clip = AudioSystem.getClip();
            clip.open(ais);
            clip.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void openFile(File file) {
        try {
            Desktop.getDesktop().open(file);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Impossible d'ouvrir le fichier.", "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void updateUserList(String names) {
        SwingUtilities.invokeLater(() -> {
            listModel.clear();
            destSelector.removeAllItems();
            destSelector.addItem("TOUS");
            for (String n : names.split(",")) {
                if (!n.isEmpty() && !n.equals(name)) {
                    listModel.addElement(n);
                    destSelector.addItem(n);
                }
            }
        });
    }

    public static void main(String[] args) {
        new ChatClient("localhost", 5000);
    }
}