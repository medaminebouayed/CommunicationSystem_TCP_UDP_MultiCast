import java.io.*;
import java.net.*;
import java.util.*;

public class ChatServer {
    private static final int PORT = 5000;
    private static final Map<String, Socket> clientSockets = Collections.synchronizedMap(new HashMap<>());
    private static final Map<String, DataOutputStream> clientStreams = Collections.synchronizedMap(new HashMap<>());

    public static void main(String[] args) {
        System.out.println("✅ Serveur chat + image + vocal + fichier démarré sur le port " + PORT);
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            while (true) {
                Socket clientSocket = serverSocket.accept();
                new Thread(new ClientHandler(clientSocket)).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static class ClientHandler implements Runnable {
        private Socket socket;
        private String name;
        private DataInputStream in;
        private DataOutputStream out;

        public ClientHandler(Socket socket) {
            this.socket = socket;
        }

        public void run() {
            try {
                in = new DataInputStream(socket.getInputStream());
                out = new DataOutputStream(socket.getOutputStream());

                name = in.readUTF();
                clientSockets.put(name, socket);
                clientStreams.put(name, out);

                broadcast("🟢 " + name + " a rejoint le chat !");
                sendClientList();

                while (true) {
                    String type = in.readUTF();

                    if (type.equals("TEXT")) {
                        String dest = in.readUTF();
                        String timestamp = in.readUTF();
                        String msg = in.readUTF();
                        if (dest.equalsIgnoreCase("TOUS")) {
                            broadcast("[" + timestamp + "] " + name + " : " + msg);
                        } else {
                            sendPrivate(dest, "[" + timestamp + "] (privé de " + name + ") : " + msg);
                        }
                    }
                    else if (type.equals("IMG")) {
                        String dest = in.readUTF();
                        String filename = in.readUTF();
                        int size = in.readInt();
                        byte[] data = new byte[size];
                        in.readFully(data);
                        if (dest.equalsIgnoreCase("TOUS")) {
                            for (DataOutputStream dos : clientStreams.values()) {
                                sendImage(dos, filename, name, data);
                            }
                        } else {
                            DataOutputStream dos = clientStreams.get(dest);
                            if (dos != null) sendImage(dos, filename, name, data);
                        }
                    }
                    else if (type.equals("AUDIO")) {
                        String dest = in.readUTF();
                        String filename = in.readUTF();
                        int size = in.readInt();
                        byte[] data = new byte[size];
                        in.readFully(data);
                        if (dest.equalsIgnoreCase("TOUS")) {
                            for (DataOutputStream dos : clientStreams.values()) {
                                sendAudio(dos, filename, name, data);
                            }
                        } else {
                            DataOutputStream dos = clientStreams.get(dest);
                            if (dos != null) sendAudio(dos, filename, name, data);
                        }
                    }
                    // 🔽 New FILE handling
                    else if (type.equals("FILE")) {
                        String dest = in.readUTF();
                        String filename = in.readUTF();
                        int size = in.readInt();
                        byte[] data = new byte[size];
                        in.readFully(data);
                        if (dest.equalsIgnoreCase("TOUS")) {
                            for (DataOutputStream dos : clientStreams.values()) {
                                sendFile(dos, filename, name, data);
                            }
                        } else {
                            DataOutputStream dos = clientStreams.get(dest);
                            if (dos != null) sendFile(dos, filename, name, data);
                        }
                    }
                }

            } catch (IOException e) {
                System.out.println("❌ " + name + " déconnecté.");
            } finally {
                clientSockets.remove(name);
                clientStreams.remove(name);
                broadcast("🔴 " + name + " a quitté le chat !");
                sendClientList();
                try { socket.close(); } catch (IOException ignored) {}
            }
        }

        private void sendImage(DataOutputStream dos, String filename, String sender, byte[] data) throws IOException {
            synchronized (dos) {
                dos.writeUTF("IMG");
                dos.writeUTF(sender);
                dos.writeUTF(filename);
                dos.writeInt(data.length);
                dos.write(data);
                dos.flush();
            }
        }

        private void sendAudio(DataOutputStream dos, String filename, String sender, byte[] data) throws IOException {
            synchronized (dos) {
                dos.writeUTF("AUDIO");
                dos.writeUTF(sender);
                dos.writeUTF(filename);
                dos.writeInt(data.length);
                dos.write(data);
                dos.flush();
            }
        }

        private void sendFile(DataOutputStream dos, String filename, String sender, byte[] data) throws IOException {
            synchronized (dos) {
                dos.writeUTF("FILE");
                dos.writeUTF(sender);
                dos.writeUTF(filename);
                dos.writeInt(data.length);
                dos.write(data);
                dos.flush();
            }
        }

        private void sendPrivate(String to, String msg) {
            DataOutputStream dos = clientStreams.get(to);
            if (dos != null) {
                try {
                    synchronized (dos) {
                        dos.writeUTF("TEXT");
                        dos.writeUTF("PRIVATE");
                        dos.writeUTF(msg);
                        dos.flush();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        private void broadcast(String msg) {
            for (DataOutputStream dos : clientStreams.values()) {
                try {
                    synchronized (dos) {
                        dos.writeUTF("TEXT");
                        dos.writeUTF("ALL");
                        dos.writeUTF(msg);
                        dos.flush();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        private void sendClientList() {
            StringBuilder list = new StringBuilder();
            for (String n : clientStreams.keySet()) list.append(n).append(",");
            String listStr = list.toString();
            for (DataOutputStream dos : clientStreams.values()) {
                try {
                    synchronized (dos) {
                        dos.writeUTF("LISTE");
                        dos.writeUTF(listStr);
                        dos.flush();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}